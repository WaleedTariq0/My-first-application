package com.example.cp4;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Bind the TextViews
        TextView textViewDisplay = findViewById(R.id.textViewDisplay);
        TextView textViewDisplay1 = findViewById(R.id.textViewDisplay1);

        // Get data from Intent extras
        String phoneNumber = getIntent().getStringExtra("phone");
        String message = getIntent().getStringExtra("message");

        // Set the received data to the TextViews
        textViewDisplay.setText(phoneNumber != null ? phoneNumber : "No Phone Number Found");
        textViewDisplay1.setText(message != null ? message : "No Message Found");
    }
}
