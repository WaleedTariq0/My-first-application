package com.example.cp4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind the views
        EditText editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        EditText editTextMessage = findViewById(R.id.editTextMessage);
        Button sendSMSButton = findViewById(R.id.SendSMS);

        // Set onClickListener for the button
        sendSMSButton.setOnClickListener(v -> {
            // Retrieve user inputs
            String phone = editTextPhoneNumber.getText().toString();
            String message = editTextMessage.getText().toString();

            // Create intent to navigate to MainActivity2
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            intent.putExtra("phone", phone);
            intent.putExtra("message", message);
            startActivity(intent);
        });
    }
}
